package com.mytasks.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.ZoneId

object TaskNotifications {
    const val CHANNEL_ID = "my_tasks_reminders"
    const val EXTRA_TASK_ID = "task_id"
    const val EXTRA_ACTION = "task_action"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Lembretes de atividades", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Avisos das atividades programadas no My Tasks"
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun schedule(context: Context, task: Task) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TaskAlarmReceiver::class.java).putExtra(EXTRA_TASK_ID, task.id)
        val pending = PendingIntent.getBroadcast(context, task.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val millis = task.startDateTime().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (millis <= System.currentTimeMillis()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, millis, pending)
        } catch (_: SecurityException) {
            alarm.set(AlarmManager.RTC_WAKEUP, millis, pending)
        }
    }

    fun cancel(context: Context, task: Task) {
        val intent = Intent(context, TaskAlarmReceiver::class.java).putExtra(EXTRA_TASK_ID, task.id)
        val pending = PendingIntent.getBroadcast(context, task.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    fun show(context: Context, task: Task) {
        createChannel(context)
        fun actionIntent(action: String, request: Int): PendingIntent {
            val i = Intent(context, TaskActionReceiver::class.java)
                .putExtra(EXTRA_TASK_ID, task.id).putExtra(EXTRA_ACTION, action)
            return PendingIntent.getBroadcast(context, task.id.hashCode() + request, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Hora de: ${task.title}")
            .setContentText("${task.start}–${task.end} • Qual é sua decisão?")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Fiz", actionIntent("DONE", 1))
            .addAction(0, "Não fiz", actionIntent("MISSED", 2))
            .build()
        context.getSystemService(NotificationManager::class.java).notify(task.id.hashCode(), notification)
    }
}

class TaskAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(TaskNotifications.EXTRA_TASK_ID) ?: return
        val task = TaskStore.load(context).firstOrNull { it.id == id } ?: return
        if (task.status == "PENDING") TaskNotifications.show(context, task)
    }
}

class TaskActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(TaskNotifications.EXTRA_TASK_ID) ?: return
        val action = intent.getStringExtra(TaskNotifications.EXTRA_ACTION) ?: return
        val tasks = TaskStore.load(context)
        val index = tasks.indexOfFirst { it.id == id }
        if (index < 0 || tasks[index].status != "PENDING") return
        val task = tasks[index]
        tasks[index] = task.copy(status = action, pointsAwarded = action == "DONE")
        TaskStore.save(context, tasks)
        if (action == "DONE") TaskStore.addPoints(context, 10)
        context.getSystemService(NotificationManager::class.java).cancel(id.hashCode())
    }
}
