package com.mytasks.app

import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.Duration
import java.util.UUID

data class Task(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val date: String,
    val start: String,
    val end: String,
    val status: String = "PENDING",
    val pointsAwarded: Boolean = false
) {
    fun startDateTime(): LocalDateTime = LocalDateTime.of(LocalDate.parse(date), LocalTime.parse(start))
    fun endDateTime(): LocalDateTime = LocalDateTime.of(LocalDate.parse(date), LocalTime.parse(end))
    fun durationMinutes(): Long = maxOf(0, Duration.between(startDateTime(), endDateTime()).toMinutes())

    fun toJson(): JSONObject = JSONObject().put("id", id).put("title", title)
        .put("date", date).put("start", start).put("end", end)
        .put("status", status).put("pointsAwarded", pointsAwarded)

    companion object {
        fun fromJson(o: JSONObject) = Task(
            id = o.optString("id", UUID.randomUUID().toString()),
            title = o.optString("title", "Atividade"),
            date = o.optString("date", LocalDate.now().toString()),
            start = o.optString("start", "09:00"),
            end = o.optString("end", "10:00"),
            status = o.optString("status", "PENDING"),
            pointsAwarded = o.optBoolean("pointsAwarded", false)
        )
    }
}
