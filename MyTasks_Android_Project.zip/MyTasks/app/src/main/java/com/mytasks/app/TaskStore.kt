package com.mytasks.app

import android.content.Context
import org.json.JSONArray

object TaskStore {
    private const val PREFS = "my_tasks_data"
    private const val TASKS = "tasks"
    private const val POINTS = "points"

    fun load(context: Context): MutableList<Task> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TASKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i -> Task.fromJson(arr.getJSONObject(i)) }
    }

    fun save(context: Context, tasks: List<Task>) {
        val arr = JSONArray()
        tasks.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TASKS, arr.toString()).apply()
    }

    fun points(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(POINTS, 0)

    fun addPoints(context: Context, amount: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(POINTS, prefs.getInt(POINTS, 0) + amount).apply()
    }
}
