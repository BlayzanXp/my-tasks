package com.mytasks.app

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val Bg = Color(0xFF0D1117)
private val Panel = Color(0xFF161B22)
private val Green = Color(0xFF65E6A5)
private val Muted = Color(0xFF9AA4B2)
private val White = Color(0xFFF4F7FA)

class MainActivity : ComponentActivity() {
    private val requestNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskNotifications.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MyTasksApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTasksApp() {
    val context = LocalContext.current
    var tasks by remember { mutableStateOf(TaskStore.load(context).sortedBy { it.startDateTime() }) }
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val today = LocalDate.now().toString()
    val todayTasks = tasks.filter { it.date == today }.sortedBy { it.start }
    val done = tasks.count { it.status == "DONE" }
    val missed = tasks.count { it.status == "MISSED" }
    val totalClosed = done + missed
    val rate = if (totalClosed == 0) 0 else (done * 100 / totalClosed)
    val points = TaskStore.points(context)
    val level = when { points >= 1000 -> "Lenda"; points >= 500 -> "Disciplinado"; points >= 200 -> "Consistente"; points >= 50 -> "Iniciante II"; else -> "Iniciante" }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel, onBackground = White,
        onSurface = White, onPrimary = Bg, secondary = Green
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text("MY TASKS", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text(if (tab == 0) "Organize seu dia." else "Sua evolução.", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = White)
                    Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd/MM")), color = Muted, fontSize = 13.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Today, null) }, label = { Text("Hoje") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text("Relatórios") })
                }
            },
            floatingActionButton = {
                if (tab == 0) FloatingActionButton(onClick = { showAdd = true }, containerColor = Green, contentColor = Bg) {
                    Icon(Icons.Default.Add, contentDescription = "Adicionar atividade")
                }
            }
        ) { padding ->
            if (tab == 0) {
                LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            StatCard("PONTOS", points.toString(), level, Modifier.weight(1f))
                            StatCard("CONCLUÍDO", "$rate%", "$done feitas • $missed não feitas", Modifier.weight(1f))
                        }
                    }
                    item { Text("AGENDA DE HOJE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
                    if (todayTasks.isEmpty()) item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Seu dia começa aqui", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                Text("Adicione uma atividade e transforme planos em ação.", color = Muted, fontSize = 13.sp)
                            }
                        }
                    }
                    items(todayTasks, key = { it.id }) { task ->
                        TaskCard(task,
                            onDone = { updateTask(context, tasks, task, "DONE") { tasks = it } },
                            onMissed = { updateTask(context, tasks, task, "MISSED") { tasks = it } },
                            onReset = { updateTask(context, tasks, task, "PENDING") { tasks = it } })
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            } else {
                val weekStart = LocalDate.now().minusDays((LocalDate.now().dayOfWeek.value - 1).toLong())
                val monthStart = LocalDate.now().withDayOfMonth(1)
                val weekly = tasks.filter { runCatching { LocalDate.parse(it.date).isAfter(weekStart.minusDays(1)) && !LocalDate.parse(it.date).isAfter(weekStart.plusDays(6)) }.getOrDefault(false) }
                val monthly = tasks.filter { runCatching { !LocalDate.parse(it.date).isBefore(monthStart) && !LocalDate.parse(it.date).isAfter(LocalDate.now()) }.getOrDefault(false) }
                LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item { Text("ESTA SEMANA", color = Green, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
                    item { ReportCard("Semana atual", weekly) }
                    item { Text("ESTE MÊS", color = Green, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
                    item { ReportCard("Mês atual", monthly) }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("SEU RANK", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(level, color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("$points pontos acumulados • +10 por atividade concluída", color = Muted, fontSize = 13.sp)
                                Text("Próximo nível: ${when { points < 50 -> 50-points; points < 200 -> 200-points; points < 500 -> 500-points; points < 1000 -> 1000-points; else -> 0 }} pontos", color = White, fontSize = 13.sp)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
        if (showAdd) AddTaskDialog(
            onDismiss = { showAdd = false },
            onSave = { task ->
                val updated = (tasks + task).sortedBy { it.startDateTime() }
                tasks = updated
                TaskStore.save(context, updated)
                TaskNotifications.schedule(context, task)
                showAdd = false
            }
        )
    }
}

@Composable
fun StatCard(label: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Green, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun TaskCard(task: Task, onDone: () -> Unit, onMissed: () -> Unit, onReset: () -> Unit) {
    val statusLabel = when(task.status) { "DONE" -> "CONCLUÍDA"; "MISSED" -> "NÃO REALIZADA"; else -> "PENDENTE" }
    val statusColor = when(task.status) { "DONE" -> Green; "MISSED" -> Color(0xFFFF7B72); else -> Color(0xFFFFD166) }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(task.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("${task.start} – ${task.end}  •  ${task.durationMinutes()/60}h ${task.durationMinutes()%60}min", color = Muted, fontSize = 12.sp)
                }
                Text(statusLabel, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            if (task.status == "PENDING") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDone, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp)); Text("Fiz", color = Green)
                }
                OutlinedButton(onClick = onMissed, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Close, null, tint = Color(0xFFFF7B72), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp)); Text("Não fiz", color = Color(0xFFFF7B72))
                }
            } else TextButton(onClick = onReset) { Text("Corrigir resultado") }
        }
    }
}

@Composable
fun ReportCard(title: String, list: List<Task>) {
    val done = list.count { it.status == "DONE" }
    val missed = list.count { it.status == "MISSED" }
    val pending = list.count { it.status == "PENDING" }
    val closed = done + missed
    val percent = if (closed == 0) 0 else done * 100 / closed
    val plannedHours = list.sumOf { it.durationMinutes() } / 60.0
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ReportMetric("Feitas", done.toString(), Green)
                ReportMetric("Não feitas", missed.toString(), Color(0xFFFF7B72))
                ReportMetric("Pendentes", pending.toString(), Color(0xFFFFD166))
            }
            LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth(), color = Green, trackColor = Color(0xFF30363D))
            Text("$percent% de conclusão • ${"%.1f".format(java.util.Locale.US, plannedHours)} horas planejadas", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun ReportMetric(label: String, value: String, color: Color) {
    Column {
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun AddTaskDialog(onDismiss: () -> Unit, onSave: (Task) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var start by remember { mutableStateOf("12:00") }
    var end by remember { mutableStateOf("14:00") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Nova atividade", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Nome da atividade") }, singleLine = true)
                OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Data (AAAA-MM-DD)") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickTime(context, start) { start = it } }, modifier = Modifier.weight(1f)) { Text("Início: $start") }
                    OutlinedButton(onClick = { pickTime(context, end) { end = it } }, modifier = Modifier.weight(1f)) { Text("Fim: $end") }
                }
                Text("Duração: ${durationText(start, end)}", color = Green, fontSize = 13.sp)
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF7B72), fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = {
                val valid = runCatching {
                    val d = LocalDate.parse(date)
                    val s = LocalTime.parse(start)
                    val e = LocalTime.parse(end)
                    d.toString().isNotBlank() && e.isAfter(s)
                }.getOrDefault(false)
                if (title.isBlank()) error = "Digite o nome da atividade."
                else if (!valid) error = "Confira a data e os horários. O fim deve ser depois do início."
                else onSave(Task(title = title.trim(), date = date, start = start, end = end))
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

fun pickTime(context: android.content.Context, current: String, onPicked: (String) -> Unit) {
    val parts = current.split(":")
    TimePickerDialog(context, { _, h, m -> onPicked("%02d:%02d".format(h, m)) },
        parts.getOrNull(0)?.toIntOrNull() ?: 12, parts.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
}

fun durationText(start: String, end: String): String = runCatching {
    val minutes = java.time.Duration.between(LocalTime.parse(start), LocalTime.parse(end)).toMinutes()
    if (minutes <= 0) "horário inválido" else "${minutes/60}h ${minutes%60}min"
}.getOrDefault("horário inválido")

fun updateTask(context: android.content.Context, current: List<Task>, task: Task, status: String, onUpdated: (List<Task>) -> Unit) {
    val updated = current.map {
        if (it.id == task.id) {
            if (status == "DONE" && it.status != "DONE") TaskStore.addPoints(context, 10)
            it.copy(status = status, pointsAwarded = status == "DONE")
        } else it
    }.sortedBy { it.startDateTime() }
    TaskStore.save(context, updated)
    onUpdated(updated)
}
