# My Tasks — Android MVP

Aplicativo Android nativo em Kotlin + Jetpack Compose.

## Funcionalidades desta primeira versão
- Criar atividades com título, data, horário inicial e final.
- Agenda do dia e duração calculada.
- Notificação agendada com ações rápidas “Fiz” e “Não fiz”.
- Marcação manual de resultado.
- Relatórios semanal e mensal com feitas, não feitas, pendentes e percentual de conclusão.
- Pontos (10 por atividade concluída) e níveis pessoais.
- Persistência local no aparelho.

## Como compilar
1. Instale Android Studio recente e um JDK 17.
2. Abra a pasta `MyTasks` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 quando solicitado.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- Android 13+ pede permissão para notificações.
- A precisão dos alarmes pode depender da permissão de alarmes exatos e das restrições de bateria do aparelho.
- Dados são armazenados localmente; não há conta, nuvem nem ranking entre usuários nesta versão.
- O MVP não reprograma alarmes após reiniciar o aparelho e ainda não tem edição/exclusão de atividades.
